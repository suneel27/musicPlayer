Music Player build using Java Spring Boot
